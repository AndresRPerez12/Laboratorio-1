
package modelo;

/**
 *
 * @author Nicolas
 */
public class Producto {
    private String nombre;
    private float precioVenta;
    private float precioVentaPorMayor;
    private float precioCompra;
    private int cantidad;
    private Proveedor proveedor;

    public Producto(String nombre, float precioVenta,float precioVentaPorMayor ,float precioCompra, int cantidad, Proveedor proveedor) {
        this.nombre = nombre;
        this.precioVenta = precioVenta;
        this.precioVentaPorMayor = precioVentaPorMayor;
        this.precioCompra = precioCompra;
        this.cantidad = cantidad;
        this.proveedor = proveedor;
    }

    public String getNombre() {
        return nombre;
    }

    public float getPrecioVenta() {
        return precioVenta;
    }

    public float getPrecioVentaPorMayor() {
        return precioVentaPorMayor;
    }

    public float getPrecioCompra() {
        return precioCompra;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setPrecioVentaPorMayor(float precioVentaPorMayor) {
        this.precioVentaPorMayor = precioVentaPorMayor;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    public void setPrecioVenta(float precioVenta) {
        this.precioVenta = precioVenta;
    }

    public void setPrecioCompra(float precioCompra) {
        this.precioCompra = precioCompra;
    }

    public void setCantidad(int x) {
        this.cantidad = cantidad+x;
    }

    public void setProveedor(Proveedor proveedor) {
        this.proveedor = proveedor;
    }

    @Override
    public String toString() {
        return "Producto: " + nombre;
    }

}
