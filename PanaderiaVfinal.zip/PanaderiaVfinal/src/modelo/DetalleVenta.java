
package modelo;

import java.util.Date;

/**
 *
 * @author Nicolas
 */
public class DetalleVenta {
    private Producto producto;
    private int cantidad;
    private Date fecha;
    private Cliente cliente;
    private float valor;

    public DetalleVenta(Producto producto, int cantidad, Cliente cliente) {
        this.producto = producto;
        this.cantidad = cantidad;
        this.fecha = new Date();
        this.cliente = cliente;
    }

    public Producto getProducto() {
        return producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public Date getFecha() {
        return fecha;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public float getValor() {
        return valor;
    }
    
}
