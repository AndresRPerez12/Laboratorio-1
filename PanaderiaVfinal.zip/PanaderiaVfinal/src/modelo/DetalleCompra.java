
package modelo;

import java.util.Date;

/**
 *
 * @author Nicolas
 */
public class DetalleCompra {
    private Producto producto;
    private int cantidad;
    private Date fecha;
    private Proveedor proveedor;
    private float valor;

    public DetalleCompra(Producto producto, int cantidad, Proveedor proveedor) {
        this.producto = producto;
        this.cantidad = cantidad;
        this.fecha = new Date();
        this.proveedor = proveedor;
    }

    public Producto getProducto() {
        return producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public Date getFecha() {
        return fecha;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    public void setValor(float valor) {
        this.valor = valor;
    }

    public float getValor() {
        return valor;
    }
    
}
