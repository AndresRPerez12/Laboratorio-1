
package vista;

import java.util.Scanner;
import modelo.Cliente;
import modelo.Panaderia;
import modelo.Proveedor;

/**
 *
 * @author Nicolas
 */
public class Main {
    public static void main(String[] args) {
        
        Scanner teclado=new Scanner(System.in);
        
        String nombre, telefono,direccion,horario,eMail;
        int proveedorParaProducto, cantidad, opcion, productoOpcion, clienteOpcion;
        float precioVentaPorMayor,precioVentaPorMenor,precioCompra,dineroEnCaja;
        Proveedor proveedorProducto = null;
        
        //se crea la panaderia 1
        Panaderia panaderia1=new Panaderia("El Triunfo","1234567","Calle 21#36-22","6 am a 9 pm",100000);
        /*System.out.print("\t\t**Sistema de compra y venta** \n\nRegistro de datos de la panaderia\n");
        System.out.print("Nombre: ");
        nombre=teclado.nextLine();
        System.out.print("Telefono: ");
        telefono=teclado.nextLine();
        System.out.print("Direccion: ");
        direccion=teclado.nextLine();
        System.out.print("Horario: ");
        horario=teclado.nextLine();
        System.out.print("Dinero en caja: ");
        dineroEnCaja=teclado.nextFloat();
        System.out.println("");
        teclado.nextLine();
        
        Panaderia panaderia1=new Panaderia(nombre,telefono,direccion,horario,dineroEnCaja);*/
        
        //se cren 2 proveedores
        Proveedor proveedor1=new Proveedor("Gastro Arte","6754098","gastroarte@proveedor.com");
        panaderia1.getDirectorioProveedores().add(proveedor1);
        Proveedor proveedor2=new Proveedor("PANNETTE","7677433","pannette@proveedor.com");
        panaderia1.getDirectorioProveedores().add(proveedor2);
        
        //se crean 2 clientes
        Cliente cliente1=new Cliente("Nicolas","8751232","calle 13#89-06");
        panaderia1.getDirectorioClientes().add(cliente1);
        Cliente cliente2=new Cliente("Sylvia","1120956","calle 23#12-98");
        panaderia1.getDirectorioClientes().add(cliente2);
        
        //se agregan 2 productos al inventario
        panaderia1.getInventario().addProducto("Mogolla", 300, 270,200, 40, proveedor1);
        panaderia1.getInventario().addProducto("Rosquilla", 500, 460,350, 100, proveedor2);
        
        int numeroProveedores=2,numeroClientes=2,numeroProductos=2;//los qye ya fueron creados, 2 de cada uno
        
        do{
            System.out.print("\n\t*Menu*\n1.  Agregar proveedor.\n2.  Agregar cliente.\n3.  Agregar producto."
                + "\n4.  Eliminar producto.\n5.  Cambiar precio de venta al por menor de un producto."
                + "\n6.  Realizar compra a proveedor.\n7.  Realizar venta al por menor."
                + "\n8.  Realizar venta al por mayor.\n9.  Mostrar inventario. \n10. Mostrar caja."
                + "\n11. Mostrar historial de compras a provedores.\n12. Mostrar historial de ventas al por menor."
                + "\n13. Mostrar historial de ventas al por mayor."
                + "\n14. Mostrar historial de clientes que han comprado al por menor."
                + "\n15. Mostrar historial de clientes que han comprado al por mayor.\n16. Informacion de la panaderia."
                + "\n17. Mostrar el historial mensual de compras y ventas."
                + "\n18. Mostrar todos los registros e informacion de la panaderia. \n19. Salir."
                + "\nOpcion: ");
            opcion=teclado.nextInt();
            
            switch(opcion){
                case 1:
                teclado.nextLine();
                System.out.print("\nProveedor " +(numeroProveedores+1)+"\n"+"Nombre: ");
                nombre=teclado.nextLine();
                System.out.print("Telefono: ");
                telefono=teclado.nextLine();
                System.out.print("E-Mail: ");
                eMail=teclado.nextLine();
                System.out.println("");
        
                Proveedor proveedor=new Proveedor(nombre,telefono,eMail);
                panaderia1.getDirectorioProveedores().add(proveedor);
                numeroProveedores++;
                break;
                
                case 2:
                teclado.nextLine();    
                System.out.print("\nCliente " +(numeroClientes+1)+"\n"+ "Nombre: ");
                nombre=teclado.nextLine();
                System.out.print("Telefono: ");
                telefono=teclado.nextLine();
                System.out.print("Direccion: ");
                direccion=teclado.nextLine();
                System.out.println("");
        
                Cliente cliente=new Cliente(nombre,telefono,direccion);
                panaderia1.getDirectorioClientes().add(cliente);
                numeroClientes++;
                break;
            
                case 3:
                teclado.nextLine();    
                System.out.print("\nProducto " +(numeroProductos+1)+"\n"+ "Nombre: ");
                nombre=teclado.nextLine();
                System.out.print("Precio venta por menor: ");
                precioVentaPorMenor=teclado.nextFloat();
                System.out.print("Precio venta por mayor: ");
                precioVentaPorMayor=teclado.nextFloat();
                System.out.print("Precio compra: ");
                precioCompra=teclado.nextFloat();
                System.out.print("Cantidad: ");
                cantidad=teclado.nextInt();
                System.out.print("\n"+panaderia1.mostrarProveedores());
                do{
                    System.out.print("Proveedor (numero): ");
                    proveedorParaProducto=teclado.nextInt();
                }while(proveedorParaProducto<0 || proveedorParaProducto>numeroProveedores);
                proveedorProducto=panaderia1.getDirectorioProveedores().get(proveedorParaProducto-1);
                teclado.nextLine();
                System.out.println("");
            
                panaderia1.getInventario().addProducto(nombre, precioVentaPorMenor, precioVentaPorMayor,
                    precioCompra, cantidad, proveedorProducto);
                numeroProductos++;
                break;
            
                case 4:
                teclado.nextLine(); 
                System.out.print("\n"+panaderia1.getInventario().toString2());
                do{
                    System.out.print("Numero del producto a eliminar: ");
                    productoOpcion=teclado.nextInt();
                }while(productoOpcion<1 || productoOpcion> numeroProductos);
                panaderia1.getInventario().deleteProducto(productoOpcion-1);
                numeroProductos--;
                break;   
                
                case 5:
                teclado.nextLine();
                System.out.print("\n"+panaderia1.getInventario().toString3());
                do{
                    System.out.print("Numero del producto: ");
                    productoOpcion=teclado.nextInt();
                }while(productoOpcion<1 || productoOpcion> numeroProductos);
                System.out.print("Nuevo precio: ");
                precioVentaPorMenor=teclado.nextFloat();
                panaderia1.getInventario().getProductoN(productoOpcion-1).setPrecioVenta(precioVentaPorMenor);
                break; 
            
                case 6:
                teclado.nextLine();
                System.out.print("\n"+panaderia1.getInventario().toString2());
                do{
                    System.out.print("Numero del producto: ");
                    productoOpcion=teclado.nextInt();
                }while(productoOpcion<1 || productoOpcion> numeroProductos);
                System.out.print("Cantidad: ");
                cantidad=teclado.nextInt();
                panaderia1.addCompra(panaderia1.getInventario().getProductoN(productoOpcion-1), cantidad, 
                    panaderia1.getDirectorioProveedores().get(productoOpcion-1),productoOpcion-1);
                panaderia1.getInventario().getProductoN(productoOpcion-1).setCantidad(cantidad);
                panaderia1.getCaja().setEgresos(panaderia1.getInventario().getProductoN(productoOpcion-1).getPrecioCompra()*cantidad); 
                System.out.println("");
                break;
                
                case 7:
                teclado.nextLine();
                System.out.print("\n"+panaderia1.getInventario().toString2());
                do{
                    System.out.print("Numero del producto: ");
                    productoOpcion=teclado.nextInt();
                }while(productoOpcion<1 || productoOpcion> numeroProductos);
                do{
                    System.out.print("Cantidad: ");
                    cantidad=teclado.nextInt();
                }while(cantidad<1 || cantidad>panaderia1.getInventario().getProductoN(productoOpcion-1).getCantidad());
                System.out.print("\n"+panaderia1.mostrarClientes());
                do{
                    System.out.print("Cliente (numero): ");
                    clienteOpcion=teclado.nextInt();
                }while(clienteOpcion<0 || clienteOpcion>numeroClientes);
                panaderia1.addVentaPorMenor(panaderia1.getInventario().getProductoN(productoOpcion-1), cantidad, 
                    panaderia1.getDirectorioClientes().get(clienteOpcion-1),productoOpcion-1);
                panaderia1.getInventario().getProductoN(productoOpcion-1).setCantidad(-cantidad);
                panaderia1.getCaja().setIngresos(panaderia1.getInventario().getProductoN(productoOpcion-1).getPrecioVenta()*cantidad);
                System.out.println("");
                break;
                
                case 8:
                teclado.nextLine();
                System.out.print("\n"+panaderia1.getInventario().toString2());
                do{
                    System.out.print("Numero del producto: ");
                    productoOpcion=teclado.nextInt();
                }while(productoOpcion<1 || productoOpcion> numeroProductos);
                do{
                    System.out.print("Cantidad: ");
                    cantidad=teclado.nextInt();
                }while(cantidad<1 || cantidad>panaderia1.getInventario().getProductoN(productoOpcion-1).getCantidad());
                System.out.print("\n"+panaderia1.mostrarClientes());
                do{
                    System.out.print("Cliente (numero): ");
                    clienteOpcion=teclado.nextInt();
                }while(clienteOpcion<0 || clienteOpcion>numeroClientes);
                panaderia1.addVentaPorMayor(panaderia1.getInventario().getProductoN(productoOpcion-1), cantidad, 
                    panaderia1.getDirectorioClientes().get(clienteOpcion-1),productoOpcion-1);
                panaderia1.getInventario().getProductoN(productoOpcion-1).setCantidad(-cantidad);
                panaderia1.getCaja().setIngresos(panaderia1.getInventario().getProductoN(productoOpcion-1).getPrecioVentaPorMayor()*cantidad);
                System.out.println("");
                break; 
                
                case 9:
                    System.out.println("\n\t\t\t\t\t\tInventario\n"+panaderia1.getInventario().toString());
                break;
                
                case 10:
                    panaderia1.getCaja().setBalance();
                    System.out.println("\n"+panaderia1.getCaja().toString());
                    break;  
                case 11:
                    System.out.print("\n\tMarzo (actual)\nHistorial de compras a provedores\n"+panaderia1.mostrarHistorialDeCompras());
                    System.out.println("Total: $"+panaderia1.totalCompras()+"\n");
                break;
                case 12:
                    System.out.print("\n\tMarzo (actual)\nHistorial de ventas al por menor\n"+panaderia1.mostrarHistorialDeVentasPorMenor());
                    System.out.println("Total: $"+panaderia1.totalVentasPorMenor()+"\n");
                break;
                case 13:
                    System.out.print("\n\tMarzo (actual)\nHistorial de ventas al por mayor\n"+panaderia1.mostrarHistorialDeVentasPorMayor());
                    System.out.println("Total: $"+panaderia1.totalVentasPorMayor()+"\n");
                break;
                case 14:
                    System.out.print("\n\t\tHistorial de clientes que han realizado compras al por menor\n"
                            +panaderia1.mostrarHistorialClientasDeComprasPorMenor());
                    System.out.println("Total: $"+panaderia1.totalVentasPorMenor()+"\n");
                break;
                case 15:
                    System.out.print("\n\t\tHistorial de clientes que han realizado compras al por mayor\n"
                            +panaderia1.mostrarHistorialDeClientesVentasPorMayor());
                    System.out.println("Total: $"+panaderia1.totalVentasPorMayor()+"\n");
                break;
                case 16:
                    System.out.println(panaderia1.toString());
                break;
                case 17:
                    panaderia1.getCaja().setBalance();
                    System.out.println("\n\t\t\t\tHistorial mensual de compras y ventas");
                    System.out.println("Diciembre\nCompras a proveedores: $230000.0, ventas al por menor: $753000.0, ventas "
                            + "al por mayor: $431500.0, ventas totales: $1184500.0, balance: $1238000.0");
                    System.out.println("Enero\nCompras a proveedores: $435000.0, ventas al por menor: $1023000.0, ventas "
                            + "al por mayor: $698000.0, ventas totales: $1721000.0, balance: $1498500.0");
                    System.out.println("Febrero\nCompras a proveedores: $900500.0, ventas al por menor: $1220500.0, ventas "
                            + "al por mayor: $375000.0, ventas totales: $1595500.0, balance: $1210500.0");
                    System.out.println("Marzo (actual)\nCompras a proveedores: $"+panaderia1.totalCompras()+
                            ", ventas al por menor: $"+panaderia1.totalVentasPorMenor()+", ventas al por mayor: $"
                            +panaderia1.totalVentasPorMayor()+
                            ", ventas totales: $"+(panaderia1.totalVentasPorMenor()+panaderia1.totalVentasPorMayor())
                            +", balance: $"+panaderia1.getCaja().getBalance());
                break;
                case 18:
                    teclado.nextLine();
                    panaderia1.getCaja().setBalance();
                    System.out.println(panaderia1.toString());
                    System.out.println("\n"+panaderia1.getCaja().toString());
                    System.out.println("\n\t\tDirectorio de proveedores\n"+panaderia1.mostrarProveedoresDatosCompletos());
                    System.out.println("\t\tInventario\n"+panaderia1.getInventario().toString());
                    System.out.println("\t\tDirectorio de clientes\n"+panaderia1.mostrarClientesDatosCompletos());
                    System.out.print("\tMarzo (actual)\nHistorial de compras a provedores\n"+panaderia1.mostrarHistorialDeCompras());
                    System.out.println("Total: $"+panaderia1.totalCompras()+"\n");
                    System.out.print("Historial de ventas al por menor\n"+panaderia1.mostrarHistorialDeVentasPorMenor());
                    System.out.println("Total: $"+panaderia1.totalVentasPorMenor()+"\n");
                    System.out.print("Historial de ventas al por mayor\n"+panaderia1.mostrarHistorialDeVentasPorMayor());
                    System.out.println("Total: $"+panaderia1.totalVentasPorMayor()+"\n");
                    System.out.println("Ventas totales: $"+(panaderia1.totalVentasPorMenor()+panaderia1.totalVentasPorMayor()));
                    System.out.println("\n\t\tHistorial mensual de compras y ventas");
                    System.out.println("Diciembre\nCompras a proveedores: $230000.0, ventas al por menor: $753000.0, ventas "
                            + "al por mayor: $431500.0, ventas totales: $1184500.0, balance: $1238000.0");
                    System.out.println("Enero\nCompras a proveedores: $435000.0, ventas al por menor: $1023000.0, ventas "
                            + "al por mayor: $698000.0, ventas totales: $1721000.0, balance: $1498500.0");
                    System.out.println("Febrero\nCompras a proveedores: $900500.0, ventas al por menor: $1220500.0, ventas "
                            + "al por mayor: $375000.0, ventas totales: $1595500.0, balance: $1210500.0");
                    System.out.println("Marzo (actual)\nCompras a proveedores: $"+panaderia1.totalCompras()+
                            ", ventas al por menor: $"+panaderia1.totalVentasPorMenor()+", ventas al por mayor: $"
                            +panaderia1.totalVentasPorMayor()+
                            ", ventas totales: $"+(panaderia1.totalVentasPorMenor()+panaderia1.totalVentasPorMayor())
                            +", balance: $"+panaderia1.getCaja().getBalance());
                break;
                case 19:
                break;
            }
        }while(opcion != 19);
    }
}