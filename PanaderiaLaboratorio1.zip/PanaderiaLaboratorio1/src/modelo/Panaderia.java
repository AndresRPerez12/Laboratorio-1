
package modelo;

import java.util.ArrayList;

/**
 *
 * @author Nicolas
 */
public class Panaderia {
    private String nombre;
    private String telefono;
    private String direccion;
    private String horario;
    private Inventario inventario;
    private Caja caja;
    private ArrayList<Cliente> directorioClientes;
    private ArrayList<Proveedor> directorioProveedores;
    private ArrayList<DetalleCompra> historialCompras;
    private ArrayList<DetalleVenta> historialVentasPorMenor;
    private ArrayList<DetalleVenta> historialVentasPorMayor;

    public Panaderia(String nombre, String telefono, String direccion, String horario, float ingresosIniciales) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.direccion = direccion;
        this.horario = horario;
        this.caja = new Caja(ingresosIniciales);
        this.inventario = new Inventario();
        this.directorioClientes = new ArrayList<>();
        this.directorioProveedores = new ArrayList<>();
        this.historialCompras = new ArrayList<>();
        this.historialVentasPorMenor = new ArrayList<>();
        this.historialVentasPorMayor = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getHorario() {
        return horario;
    }

    public Inventario getInventario() {
        return inventario;
    }

    public Caja getCaja() {
        return caja;
    }

    public ArrayList<Cliente> getDirectorioClientes() {
        return directorioClientes;
    }

    public ArrayList<Proveedor> getDirectorioProveedores() {
        return directorioProveedores;
    }

    public ArrayList<DetalleCompra> getHistorialCompras() {
        return historialCompras;
    }

    public ArrayList<DetalleVenta> getHistorialVentasPorMenor() {
        return historialVentasPorMenor;
    }

    public ArrayList<DetalleVenta> getHistorialVentasPorMayor() {
        return historialVentasPorMayor;
    }
    
    public boolean addCliente(Cliente cliente) {
        return this.directorioClientes.add(cliente);
    }
    
    public boolean addProveedor(Proveedor proveedor) {
        return this.directorioProveedores.add(proveedor);
    }
    
    public boolean addCompra(Producto producto, int cantidad, Proveedor proveedor, int posicion) {
        DetalleCompra detalle=new DetalleCompra(producto, cantidad, proveedor);
        detalle.setValor(this.inventario.getProductoN(posicion).getPrecioCompra()*cantidad);
        return this.historialCompras.add(detalle);
    }

    public boolean addVentaPorMenor(Producto producto, int cantidad, Cliente cliente,int posicion) {
        DetalleVenta detalle=new DetalleVenta(producto, cantidad, cliente);
        detalle.setValor(this.inventario.getProductoN(posicion).getPrecioVenta()*cantidad);
        return this.historialVentasPorMenor.add(detalle);
    }
    
    public boolean addVentaPorMayor(Producto producto, int cantidad, Cliente cliente,int posicion) {
        DetalleVenta detalle=new DetalleVenta(producto, cantidad, cliente);
        detalle.setValor(this.inventario.getProductoN(posicion).getPrecioVentaPorMayor()*cantidad);
        return this.historialVentasPorMayor.add(detalle);
    }

    @Override
    public String toString() {
        return "\n\t\tPanaderia "+ nombre + "\nTelefono: " + telefono + ", direccion: " + direccion + ", horario: " + horario;
    }

    public String mostrarProveedores() {
        String mostrar="";
        for (int i = 0; i < this.directorioProveedores.size(); i++) {
            mostrar+="Proveedor "+(i+1)+": "+ this.directorioProveedores.get(i).getNombre()+"\n";
        }
        return mostrar;
    }
    
    public String mostrarClientes() {
        String mostrar="";
        for (int i = 0; i < this.directorioClientes.size(); i++) {
            mostrar+="Cliente "+(i+1)+": "+ this.directorioClientes.get(i).getNombre()+"\n";
        }
        return mostrar;
    }
    
    public String mostrarClientesDatosCompletos() {
        String mostrar="";
        for (int i = 0; i < this.directorioClientes.size(); i++) {
            mostrar+="Cliente "+(i+1)+": "+ this.directorioClientes.get(i).getNombre()+", telefono: "
                    +this.directorioClientes.get(i).getTelefono()+", direccion: "
                    +this.directorioClientes.get(i).getDireccion()+"\n";
        }
        return mostrar;
    }
    
    public String mostrarProveedoresDatosCompletos() {
        String mostrar="";
        for (int i = 0; i < this.directorioProveedores.size(); i++) {
            mostrar+="Proveedor "+(i+1)+": "+ this.directorioProveedores.get(i).getNombre()+", telefono: "
                    +this.directorioProveedores.get(i).getTelefono()+", eMail: "
                    +this.directorioProveedores.get(i).getCorreo()+"\n";
        }
        return mostrar;
    }
    
    public String mostrarHistorialDeCompras() {
        String mostrar="";
        for (int i = 0; i < this.historialCompras.size(); i++) {
            mostrar+="Registro "+(i+1)+": "+ this.historialCompras.get(i).getProducto()+", fecha: "
                    +this.historialCompras.get(i).getFecha()+", Proveedor: "
                    +this.historialCompras.get(i).getProveedor()+", valor: $"
                    +this.historialCompras.get(i).getValor()+", cantidad: "+this.historialCompras.get(i).getCantidad()+"\n";
        }
        return mostrar;
    }
    
    public String mostrarHistorialDeVentasPorMenor() {
        String mostrar="";
        for (int i = 0; i < this.historialVentasPorMenor.size(); i++) {
            mostrar+="Registro "+(i+1)+": "+ this.historialVentasPorMenor.get(i).getProducto()+", fecha: "
                    +this.historialVentasPorMenor.get(i).getFecha()+", Cliente: "
                    +this.historialVentasPorMenor.get(i).getCliente()+", valor: $"
                    +this.historialVentasPorMenor.get(i).getValor()+", cantidad: "+this.historialVentasPorMenor.get(i).getCantidad()+"\n";
        }
        return mostrar;
    }
    
    public String mostrarHistorialClientasDeComprasPorMenor() {
        String mostrar="";
        for (int i = 0; i < this.historialVentasPorMenor.size(); i++) {
            mostrar+="Registro "+(i+1)+": "+this.historialVentasPorMenor.get(i).getCliente() 
                    +". "+this.historialVentasPorMenor.get(i).getProducto()+", fecha: "
                    +this.historialVentasPorMenor.get(i).getFecha()+", valor: $"
                    +this.historialVentasPorMenor.get(i).getValor()+", cantidad: "
                    +this.historialVentasPorMenor.get(i).getCantidad()+"\n";
        }
        return mostrar;
    }
    
    public String mostrarHistorialDeVentasPorMayor() {
        String mostrar="";
        for (int i = 0; i < this.historialVentasPorMayor.size(); i++) {
            mostrar+="Registro "+(i+1)+": "+ this.historialVentasPorMayor.get(i).getProducto()+", fecha: "
                    +this.historialVentasPorMayor.get(i).getFecha()+", Cliente: "
                    +this.historialVentasPorMayor.get(i).getCliente()+", valor: $"
                    +this.historialVentasPorMayor.get(i).getValor()+", cantidad: "+this.historialVentasPorMayor.get(i).getCantidad()+"\n";
        }
        return mostrar;
    }
    
    public String mostrarHistorialDeClientesVentasPorMayor() {
        String mostrar="";
        for (int i = 0; i < this.historialVentasPorMayor.size(); i++) {
            mostrar+="Registro "+(i+1)+": "+this.historialVentasPorMayor.get(i).getCliente() 
                    +". "+this.historialVentasPorMayor.get(i).getProducto()+", fecha: "
                    +this.historialVentasPorMayor.get(i).getFecha()+", valor: $"
                    +this.historialVentasPorMayor.get(i).getValor()+", cantidad: "
                    +this.historialVentasPorMayor.get(i).getCantidad()+"\n";
        }
        return mostrar;
    }
    
    public float totalCompras(){
        float total=0;
        for (int i = 0; i < this.historialCompras.size(); i++) {
            total+=this.historialCompras.get(i).getValor();
        }
        return total;
    }
    
    public float totalVentasPorMenor(){
        float total=0;
        for (int i = 0; i < this.historialVentasPorMenor.size(); i++) {
            total+=this.historialVentasPorMenor.get(i).getValor();
        }
        return total;
    }
    
    public float totalVentasPorMayor(){
        float total=0;
        for (int i = 0; i < this.historialVentasPorMayor.size(); i++) {
            total+=this.historialVentasPorMayor.get(i).getValor();
        }
        return total;
    }
    
}
