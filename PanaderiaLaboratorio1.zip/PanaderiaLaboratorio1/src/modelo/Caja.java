
package modelo;

/**
 *
 * @author Nicolas
 */
public class Caja {
    private float ingresos;
    private float egresos;
    private float balance;

    public Caja(float ingresosIniciales) {
        this.ingresos = ingresosIniciales;
        this.egresos = 0;
    }

    public float getIngresos() {
        return ingresos;
    }

    public float getEgresos() {
        return egresos;
    }

    public float getBalance() {
        return balance;
    }

    public void setIngresos(float x) {
        this.ingresos = ingresos+x;
    }

    public void setEgresos(float x) {
        this.egresos = egresos+x;
    }

    public void setBalance() {
        this.balance = this.getIngresos()-this.getEgresos();
    }

    @Override
    public String toString() {
        return "Caja: " + "ingresos: $" + ingresos + ", egresos: $" + egresos + ", balance: $" + balance;
    }
    
}
